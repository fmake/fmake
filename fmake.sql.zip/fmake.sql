-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 12, 2012 at 07:11 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fmake`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_modul`
--

CREATE TABLE IF NOT EXISTS `admin_modul` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `redir` varchar(255) NOT NULL DEFAULT '',
  `users` varchar(255) NOT NULL DEFAULT '',
  `file` varchar(255) NOT NULL DEFAULT '',
  `showinmenu` enum('1','0') NOT NULL DEFAULT '1',
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `position` int(11) NOT NULL DEFAULT '0',
  `template` varchar(255) DEFAULT '',
  `index` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `admin_modul`
--

INSERT INTO `admin_modul` (`id`, `parent`, `caption`, `text`, `redir`, `users`, `file`, `showinmenu`, `active`, `position`, `template`, `index`) VALUES
(-1, 0, 'Контент менеджер', '', '', 'God::manager', 'simple', '1', '', 1, '', '0'),
(1, 0, 'Управление сайтом', '', 'main_content', 'God::manager', 'simple', '1', '1', 2, 'simple', '1'),
(2, 1, 'Раздeлы', '', 'sitemods', 'God::manager', 'site_mods', '1', '1', 3, 'simple_table_act', '0'),
(3, 1, 'Параметры', '', 'siteconfigs', 'God::manager', 'site_configs', '1', '1', 44, '', '0'),
(5, 1, 'Администраторы', '', 'admins', 'God', 'mod_admins', '1', '1', 4, '', '0'),
(6, 0, 'Смена пароля', '', 'set_pass', 'God::manager', 'set_pass', '0', '', 7, '', '0'),
(9, 1, 'Системные сообщения', '', 'system_notice', 'God::manager', 'system_notice', '1', '1', 6, '', '0'),
(25, 1, 'Меню', '', '', 'God::manager', '', '1', '1', 0, '', '0'),
(43, 3, 'Таблица параметров', '', 'site_configs_table', 'God::manager', 'site_configs_table', '1', '1', 43, '', '0'),
(44, 1, 'Основные параметры', '', '', 'God::manager', '', '1', '1', 10, '', '0'),
(42, 50, 'Шаблоны', '', 'template', 'God::manager', 'mod_patern', '1', '1', 50, '', '0'),
(50, 0, 'Разработка', '<h1>Выберите нужный пункт слева</h1>', 'options', 'God', '', '1', '1', 42, 'simple', '0'),
(51, 50, 'Редактирования файлов', '', '', 'God', '', '1', '1', 47, '', '0'),
(52, 50, 'Управление CMS', '', '', 'God', '', '1', '1', 45, '', '0'),
(53, 50, 'Редактирование разделов', '', 'cms_content', 'God', 'simple_admin', '1', '1', 46, '', '0'),
(54, 50, 'Модули', '', 'moduls_template', 'God', 'mod_patern_modules', '1', '1', 49, '', '0'),
(55, 50, 'Классы', '', 'includes_template', 'God', 'mod_patern_includes', '1', '1', 48, '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE IF NOT EXISTS `admin_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `login` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `name`, `type`, `login`, `password`, `email`, `active`) VALUES
(1, 'Shevlyakov Nikita', 'God', 'admin', '698d51a19d8a121ce581499d7b701668', 'shevlyakov.nikita@gmail.com', '1'),
(2, 'Manager', 'manager', 'manager', '15de21c670ae7c3f6f3f1f37029303c9', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `id_module` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_module`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `modules`
--


-- --------------------------------------------------------

--
-- Table structure for table `modules_config`
--

CREATE TABLE IF NOT EXISTS `modules_config` (
  `id_modules_config` int(11) NOT NULL AUTO_INCREMENT,
  `id_module` int(11) DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `value` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_modules_config`),
  UNIQUE KEY `id_module` (`id_module`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `modules_config`
--


-- --------------------------------------------------------

--
-- Table structure for table `modules_test`
--

CREATE TABLE IF NOT EXISTS `modules_test` (
  `id_module` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `modules_test`
--


-- --------------------------------------------------------

--
-- Table structure for table `site_config`
--

CREATE TABLE IF NOT EXISTS `site_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `site_config`
--

INSERT INTO `site_config` (`id`, `param`, `value`, `active`, `description`) VALUES
(5, 'phone1', '+7(495)740-78-24', '1', 'Телефон первый'),
(6, 'phone2', '+7(495)740-78-22', '1', 'Телефон второй'),
(3, 'email', 'info@hostname.ru', '1', 'Администраторские емайлы'),
(8, 'footer', '&copy; <br />\r\nПри использовании материалов сайта ссылка обязательна.<br />\r\n<a href="http://www.venta-group.ru/"> </a>', '1', 'Футер');

-- --------------------------------------------------------

--
-- Table structure for table `site_modul`
--

CREATE TABLE IF NOT EXISTS `site_modul` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `redir` varchar(255) NOT NULL DEFAULT '',
  `file` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `index` enum('0','1') NOT NULL DEFAULT '0',
  `inmenu` enum('1','0') NOT NULL DEFAULT '1',
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `site_modul`
--

INSERT INTO `site_modul` (`id`, `parent`, `caption`, `title`, `keywords`, `description`, `text`, `redir`, `file`, `position`, `index`, `inmenu`, `active`) VALUES
(1, 0, 'Главная', 'Главная', 'Главная', '', '<p>qweqweq</p>', '', 'mod_text', 1, '1', '1', '1');
